import { NlTheme } from './index';

export interface IButton {
  theme: NlTheme;
  titleBtn: string;
  disabled: boolean;
}
