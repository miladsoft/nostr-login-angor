/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "index.html",
    "revision": "055d7c8f3eee6cd35f5fb3e3ae2729cc"
  },
  {
    "url": "build/index.esm.js",
    "revision": "369f198d729566e914b599ecc5a1ac10"
  },
  {
    "url": "build/p-0a4f9160.entry.js"
  },
  {
    "url": "build/p-1349bad3.entry.js"
  },
  {
    "url": "build/p-19a14917.entry.js"
  },
  {
    "url": "build/p-2429e539.js"
  },
  {
    "url": "build/p-36b39112.entry.js"
  },
  {
    "url": "build/p-375beffc.entry.js"
  },
  {
    "url": "build/p-3cbc346a.entry.js"
  },
  {
    "url": "build/p-53b9b87a.js"
  },
  {
    "url": "build/p-651d0f7d.js"
  },
  {
    "url": "build/p-735e01d1.js"
  },
  {
    "url": "build/p-9ce8b05e.js"
  },
  {
    "url": "build/p-ad946565.js"
  },
  {
    "url": "build/p-b75697c4.css"
  },
  {
    "url": "build/p-bb5bdb34.js"
  },
  {
    "url": "build/p-d61a32e5.entry.js"
  },
  {
    "url": "build/p-e1255160.js"
  },
  {
    "url": "build/p-e64b4047.entry.js"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {});
